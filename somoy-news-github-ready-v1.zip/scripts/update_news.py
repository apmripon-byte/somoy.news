import json, os, re, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

FEEDS = [
    ("জাতীয়", "bdnews24", "https://bdnews24.com/?widgetName=rssfeed&widgetId=1150&getXmlFeed=true"),
    ("জাতীয়", "Banglanews24", "https://www.banglanews24.com/rss/rss.xml"),
    ("জাতীয়", "Jugantor", "https://www.jugantor.com/feed/rss.xml"),
    ("জাতীয়", "Jago News24", "https://www.jagonews24.com/rss/rss.xml"),
    ("জাতীয়", "Kaler Kantho", "https://www.kalerkantho.com/rss.xml"),
    ("জাতীয়", "Prothom Alo", "https://www.prothomalo.com/feed/"),
    ("আন্তর্জাতিক", "The Daily Star", "https://www.thedailystar.net/frontpage/rss.xml"),
]

UA="Mozilla/5.0 (compatible; SomoyNewsBot/2.0)"
def clean(s):
    return re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',s or '')).strip()
def get_text(el, names):
    for n in names:
        x=el.find(n)
        if x is not None and x.text: return x.text
    return ""
def get_link(el):
    x=el.find("link")
    if x is not None and x.text: return x.text.strip()
    for x in el.findall("{http://www.w3.org/2005/Atom}link"):
        href=x.attrib.get("href")
        if href: return href
    return ""
def parse_feed(cat, source, url):
    req=urllib.request.Request(url,headers={"User-Agent":UA})
    with urllib.request.urlopen(req,timeout=20) as r: data=r.read()
    root=ET.fromstring(data)
    entries=root.findall(".//item")
    if not entries: entries=root.findall("{http://www.w3.org/2005/Atom}entry")
    out=[]
    for e in entries[:12]:
        title=clean(get_text(e,["title","{http://www.w3.org/2005/Atom}title"]))
        link=get_link(e)
        desc=clean(get_text(e,["description","summary","{http://www.w3.org/2005/Atom}summary","content:encoded"]))
        if title and link: out.append({"title":title,"link":link,"summary":desc[:280],"source":source,"category":cat,"date":""})
    return out

items=[]
for cat,source,url in FEEDS:
    try: items += parse_feed(cat,source,url)
    except Exception as ex: print("feed failed",source,ex)

seen=set(); unique=[]
for n in items:
    key=n["link"] or n["title"]
    if key in seen: continue
    seen.add(key); unique.append(n)
unique=unique[:60]
payload={"updated":datetime.now(timezone.utc).isoformat(),"items":unique}
os.makedirs("data",exist_ok=True)
with open("data/news.json","w",encoding="utf-8") as f: json.dump(payload,f,ensure_ascii=False,indent=2)
print("saved",len(unique),"items")
