# somoy.news — GitHub News Portal

Modern static Bangla news portal for GitHub Pages.

## Features
- Responsive Bangla news design
- Breaking-news ticker
- Dhaka weather
- RSS feed aggregation through GitHub Actions
- Automatic `data/news.json` refresh every 15 minutes
- Source links are preserved

## Important
The RSS updater imports headlines and short summaries with a link to the original source. Check each source's terms before republishing content or images.

## Enable GitHub Pages
Repository → Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.

## Enable automatic news updates
Repository → Actions → select **Update Somoy News** → **Run workflow** once for the first test. Scheduled runs then update `data/news.json`.

GitHub scheduled workflows can be delayed during periods of high load, so the schedule is not a guaranteed exact 15-minute clock.
